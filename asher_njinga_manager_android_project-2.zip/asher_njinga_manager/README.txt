ASHER NJINGA MANAGER — ANDROID PROJECT

This is the Android Studio source project for an offline motorcycle-business manager.

IMPORTANT:
- This ZIP is project source, not an already compiled/installable APK.
- To build the APK, open this folder in Android Studio on a computer with Android SDK installed.
- Choose Build > Build APK(s). The debug APK is normally created under app/build/outputs/apk/debug/.
- App data is stored locally in the app WebView. Use the in-app Backup feature regularly.
- No internet permission is requested; all app screens are bundled locally.
